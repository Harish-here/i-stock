<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>i-CODERS</title>

</head>

<body>
<font face="Comic Sans MS, cursive">
<img src="../icoders.png" alt="icoders logo" width="254" height="70" style align="absmiddle" /><br>
<font color="#000000" size="4" face="Comic Sans MS, cursive" algin="center" style="padding-left: 30px;">" Coding the Future..!! "</font><hr>
<p align="right">Our Release<br><a href="index.php" style="text-decoration: none;color: #000">i-STOCK<font size=1>v1.0</a></p></font>
<p align="center">"EVERYTHING SHOULD BE MADE AS SIMPLE AS POSSIBLE,BUT NOT SIMPLER" - Albert Einstein </p><br><br>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.0";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<div class="fb-like" data-href="https://www.facebook.com/harish.hari.1481" data-layout="standard" data-action="like" data-show-faces="true" data-share="true"></div>
<p>Our company aims to built an Easy,Effective and Customisble stock managament Apps for the Retailers which completely Reduces their Efforts in Managing aand Maintaining the stocks ....</p><br><p>Presently we are building the Apps Exclusively for Enterprises(stock management), Programming , Designing and building the sites.</p>
<p align="center">"HOPE WE CODE TO MAKE IT AS SIMPLE AS WE CAN,BUT NOT SIMPLER.... "</p><br><p>Contact No:+918870072346 <br>Email:harishamudha@gmail.com</p>
<p align="right" size=3px style="font-family: sans-serif;">With Regards,<br>HARISH R<br><font size=2>Founder & CEO<br><code>i-CODERS</code>.</></p><hr>
<div style="text-align:center;font-family:Georgia, 'Times New Roman', Times, serif;font-size:14px"><code>i-CODERS</code> © 2014.<br>All Rights Reserved.</div>
</body>
</html>