<html><br><br><body><head>

<meta charset="utf-8">
</head>



  <body> 
  <p style="text-align: right;"><a href="about.php"><img src="icoders.png" width="150" height="41" alt="i-CODERS logo"></a></p>

<div style="text-align: center;width: 1210px;height: auto;background-color: #393;color:#FFF;border:dashed;padding: 10px;font-size: 15px;font-style: italic;font-family:Georgia, 'Times New Roman', Times, serif;">
copyrighted © 2014 &nbsp;i-STOCK  <br>
  created and owned by <code><strong>i-CODERS</strong></code><br> All Rights Reserved.
</div></body></html>