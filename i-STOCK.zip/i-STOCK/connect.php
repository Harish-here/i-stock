<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>	
</head>
<body>
<?php
$error = "Problem connecting";
$dbc=mysqli_connect('sql102.base.pk','basep_13905977','harish','basep_13905977_contact') or die($error);
?>

</body>
</html>
